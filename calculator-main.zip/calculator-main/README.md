This is the basic calculator project where I used HTML, CSS3 and Javascript.
